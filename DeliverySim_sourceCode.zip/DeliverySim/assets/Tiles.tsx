<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Tiles" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="Tiles.png" width="256" height="256"/>
 <tile id="0" type="redDoor">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="red door"/>
  </properties>
 </tile>
 <tile id="1" type="blueDoor">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="blue door"/>
  </properties>
 </tile>
 <tile id="2" type="greenDoor">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="green door"/>
  </properties>
 </tile>
 <tile id="3" type="elevator">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="level" value="1"/>
   <property name="name" value="elevator"/>
  </properties>
 </tile>
 <tile id="4" type="stair">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="stair"/>
  </properties>
 </tile>
 <tile id="5" type="wall">
  <properties>
   <property name="canBlockMovement" type="bool" value="true"/>
   <property name="name" value="wall"/>
  </properties>
 </tile>
 <tile id="6" type="window">
  <properties>
   <property name="canBlockMovement" type="bool" value="true"/>
   <property name="name" value="glass window"/>
  </properties>
 </tile>
 <tile id="7" type="floor">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="floor"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="canBlockMovement" type="bool" value="true"/>
   <property name="name" value="locked door"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="lampost"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="lampost top"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="direction" type="int" value="1"/>
   <property name="name" value="mower"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="rocket"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="air"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="grass"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="canBlockMovement" type="bool" value="false"/>
   <property name="name" value="yellow door"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="canBlockMovement" type="bool" value="true"/>
   <property name="name" value="water"/>
  </properties>
 </tile>
</tileset>
