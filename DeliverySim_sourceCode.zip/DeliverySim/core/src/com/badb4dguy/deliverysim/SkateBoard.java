package com.badb4dguy.deliverysim;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer.Cell;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;

public class SkateBoard extends Package{
	
	
	Cell probe2;
	public SkateBoard(int initX, int initY, TiledMap map,int spawnTime) {
		super(initX, initY, map, spawnTime);
		this.rewardBase = 140;
		this.penalty = 5;
		boxTexture = new Texture("Skateboard.png");
		// TODO Auto-generated constructor stub
	}
	@Override
	void onSelected(SpriteBatch batch,TiledMapTileLayer Layer)
	{
		if (isFocused&&drive!=null)
		{
			isFocused = false;
			if(drive.isFocused == false)drive.isFocused = true;
			drive.onSelected(batch, Layer);
			moveRange = this.drive.moveRange;
		}
		if(isFocused)
		{
		for(int x = -2;x<3;x+=1)
		{
			//probe = layer.getCell((int)pos.x+x, (int)pos.y);
			
			for(int y = -2;y<3;y+=1)
			{
				layer = Layer;
				probe = layer.getCell((int)pos.x+x, (int)pos.y+y);
				
				if(probe!=null&&!(boolean)probe.getTile().getProperties().get("canBlockMovement")&&((x!=0&&y==0)||(x==0&&y!=0)))
				{
					probe = layer.getCell((int)pos.x+zero(x/2), (int)pos.y+zero(y/2));
					if(!(boolean)probe.getTile().getProperties().get("canBlockMovement"))
					{
					batch.draw(moveGrid,32*((int)pos.x+x), 32*((int)pos.y+y));	
                    destination.set((int)pos.x+x, (int)pos.y+y);
                    moveRange.add(new Vector2(destination));
					}
                    //moveRange.insert((x+1)*3+y+1, destination);
				}
				
			}
		}
		}
		else if(!isFocused)
		{
			//if(drive!=null)drive.isFocused = false;
			return;
		}
	}
	private int zero(int a)
	{
		if(a>0&&a<1) a =1;
		else if(a<0&&a>-1) a =-1;
		else if (a>=1||a<=-1) return a;
		return a;
	}
}
