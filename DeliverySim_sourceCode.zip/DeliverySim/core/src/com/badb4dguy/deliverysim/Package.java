package com.badb4dguy.deliverysim;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer.Cell;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;

public class Package {
	
	int damageSum = 0;
	int spawnTime = 0;
	int rewardBase = 100;
	int damage = 0;
	Mower drive;
	Vector2 pos;
	Vector2 destination;
	Cell probe;
	TiledMapTileLayer layer;
	protected boolean isFocused;
	int floor;
	int moves;
	Array<Vector2> moveRange;
	int reward = rewardBase;
	
	int timelimit;
	
	int penalty = 3;
	Texture contentTexture;
	Texture moveGrid;
	Texture boxTexture;
	
	public Package(int initX,int initY,TiledMap map,int time)
	{   
		spawnTime = time;
		rewardBase = 160;
		damage = 0;
		moves = 1;
		floor = 0;
		layer = (TiledMapTileLayer)map.getLayers().get(floor);
		pos = new Vector2(initX,initY);
		destination = new Vector2(-1,-1);
		isFocused = false;
		moveRange = new Array<Vector2>(12);
		probe = new Cell();
		boxTexture = new Texture("Box.png");
		moveGrid = new Texture("Box_move.png");
		drive = null;
	}
	void onSelected(SpriteBatch batch,TiledMapTileLayer Layer)
	{
		if (isFocused&&drive!=null)
		{
			isFocused = false;
			drive.isFocused = true;
			drive.onSelected(batch, Layer);
			moveRange = this.drive.moveRange;
		}
		if(isFocused)
		{
		for(int x = -1;x<2;x+=1)
		{
			//probe = layer.getCell((int)pos.x+x, (int)pos.y);
			
			for(int y = -1;y<2;y+=1)
			{
				layer = Layer;
				probe = layer.getCell((int)pos.x+x, (int)pos.y+y);
				
				if(probe!=null&&!(boolean)probe.getTile().getProperties().get("canBlockMovement")&&(x!=0||y!=0))
				{
					batch.draw(moveGrid,32*((int)pos.x+x), 32*((int)pos.y+y));	
                    destination.set((int)pos.x+x, (int)pos.y+y);
                    moveRange.add(new Vector2(destination));
                    //moveRange.insert((x+1)*3+y+1, destination);
				}
				
			}
		}
		}
		else if(!isFocused)
		{
			return;
		}
	}
	void setPos(SpriteBatch batch,int x,int y)
	{
		batch.draw(boxTexture,x*32, y*32);	
	}
}
