package com.badb4dguy.deliverysim;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Buttons;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTile;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer.Cell;
import com.badlogic.gdx.maps.tiled.TiledMapTileSet;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.maps.tiled.tiles.StaticTiledMapTile;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.badlogic.gdx.utils.ScreenUtils;

public class GameScreen implements Screen,InputProcessor {
	private TiledMap map;
	private TiledMapTileSet tileSet;
	private OrthogonalTiledMapRenderer renderer;
	private ShapeRenderer rectRenderer;
	private OrthographicCamera camera;
	private Texture boxTexture;
	private Texture tileTexture;
	private SpriteBatch batch;
	private BitmapFont font;
	private MapLayer layer;
	private TiledMapTileLayer tileLayer;
	private Cell cell;
	Cell cellTemp;
	private TiledMapTile groundTile;
	private TiledMapTile airTile;
	private int cameraFloor = 0;
	private int cursorPosx = 0,cursorPosy = 0;
	private int clickPosx = -1,clickPosy = -1;
    private int gridX,gridY;
    private int Time = 0;
            int Money = 100;
            int maxDelivered = 0;
            int maxMoney = 0;
    private boolean isClicked = false;
    private boolean stop = false;
    private String description;
    String Selected = "";
    String timePassed = " rounds have passed";
    String moneyLeft = " remains.Deliver until lose all money;";
    private String basic = "Click on anything with number to take action";
    private Array<Package> activePackages;
            Array<Mower> allMowers;
            Pool<Package> packages;
    Package deliveryBox;
    Package deliveryBox2;
    final MyGdxGame Game;
	
	public GameScreen(final MyGdxGame game) {
		// TODO Auto-generated constructor stub
		packages = new Pool<Package>()
		{
	         @Override
	         protected Package newObject()
	         {
		          return new Package(0, 0, map,Time);
	         }
		};
		map = new TmxMapLoader().load("map2.tmx");
		//deliveryBox = packages.obtain();
		//deliveryBox = new VideoGame2(25,3,map);
		//deliveryBox.floor = 0;
		//deliveryBox2 = packages.obtain();
		//deliveryBox2 = new Laptop(5,3,map);
		//deliveryBox2.floor = 0;
		boxTexture = new Texture("Box.png");
		tileTexture = new Texture("Tiles.png");
		
		tileSet = new TiledMapTileSet();
		tileSet = map.getTileSets().getTileSet(cameraFloor);
	    
		layer = map.getLayers().get(cameraFloor);
		tileLayer = (TiledMapTileLayer)map.getLayers().get(cameraFloor);

		renderer = new OrthogonalTiledMapRenderer(map,1f);
		rectRenderer = new ShapeRenderer();
		camera = new OrthographicCamera();
		camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		camera.update();
		batch = new SpriteBatch();
		font = new BitmapFont();
		cell = new Cell();
		cellTemp = new Cell();
		activePackages = new Array<Package>();
		allMowers = new Array<Mower>();
		description = basic;
		//activePackages.add(deliveryBox);
		//activePackages.add(deliveryBox2);
		
		Gdx.input.setInputProcessor(this);
		Mower mower = new Mower(7,9,map,Time);
		mower.floor = 0;
		
		Mower mower1 = new Mower(3,10,map,Time);
		mower1.floor = 1;
		Mower mower2 = new Mower(7,9,map,Time);
		mower2.floor = 2;
		Mower mower3 = new Mower(3,15,map,Time);
		mower3.floor = 3;
		
		allMowers.add(mower,mower1);
		allMowers.add(mower2,mower3);
        this.Game = game;
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		

	}

	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		
		gridUpdate();
		camera.update();
		
		renderer.getBatch().begin();
		batch.setProjectionMatrix(camera.combined);
		ScreenUtils.clear(0.5f, 0.5f, 0.5f, 1);
		renderer.setView(camera);
		//batch.begin();
		
		
		cell = tileLayer.getCell(gridX, gridY);
		
		
		renderer.renderTileLayer((TiledMapTileLayer)map.getLayers().get(cameraFloor));
		//renderer.render();
		spawnPackage();
		
		//batch.draw(boxTexture, 25*32, 2*32);
		//MapObjects obj = cell.getTile().getObjects();
		
		for(Package box:activePackages)
		{
		    if(box.floor == cameraFloor)
		    {
		
		    	if(box.pos.x==gridX&&box.pos.y==gridY)
		    	{
		    		Selected = box.getClass().getSimpleName();
		    	}
		    	else if(box.pos.x!=gridX&&box.pos.y!=gridY)
		    	{
		    		Selected = "";
		    	}
			if((box.pos.x==clickPosx&&box.pos.y==clickPosy)&&!stop&&box.getClass()!=Mower.class)
			{
				
				box.isFocused = true;
				if(box.getClass()==BlasterBox.class)
				{
				    description = "F to froze time for 5 rounds.Will be paid back after it ends";
				}
				else
				{
					description = "Click on blue mark to move to";
				}
				box.onSelected((SpriteBatch) renderer.getBatch(),(TiledMapTileLayer)map.getLayers().get(box.floor));
				//if(box.drive==null)description = ("sb");
				
			}
			
			if(box.isFocused == true&&box.drive == null&&box.getClass()==VideoGame1.class)
			{
				description = "Click on package to swap position";
				for(int i=0;i<activePackages.size;i++)
				{
					if((clickPosx==activePackages.get(i).pos.x&&clickPosy==activePackages.get(i).pos.y)&&activePackages.get(i).floor==box.floor&&!stop)
					{
						if(box.equals(activePackages.get(i)))
						{
							//description = "It's boring";
							
						}
						else if(!box.equals(activePackages.get(i)))
						{
							activePackages.get(i).pos.set(box.pos);
							box.pos.set(clickPosx,clickPosy);
							box.moveRange.clear();
							
							box.isFocused = false;
							Time++;
							stop=true;
							break;
						}
					}
				}
			}
			else if(box.isFocused == true&&box.drive != null&&box.getClass()==VideoGame1.class)
			{
				description = "You can't do this in driving";
			}
			
			
			
			if(box.isFocused == true&&box.drive == null&&box.getClass()==Laptop.class)
			{
				description = "Click on mower to remote control";
				for(Mower mower :allMowers)
				{
					if((clickPosx==mower.pos.x&&clickPosy==mower.pos.y)&&mower.floor==box.floor&&!stop)
					{
						if(mower.carrier == null)
						{
						mower.isFocused = true;
						mower.onSelected((SpriteBatch) renderer.getBatch(),(TiledMapTileLayer)map.getLayers().get(box.floor));
						}
						else if(mower.carrier != null)
						{
							description = "Can't do that.Mower is occupied";
							stop=true;
							break;
						}
					}
					
					if(mower.isFocused)
					{
						for(Vector2 point :mower.moveRange)
						{
							if((clickPosx==point.x&&clickPosy==point.y)&&isClicked==false)
							{
								cell = tileLayer.getCell((int)point.x,(int)point.y);
								if((cell.getTile().getProperties().get("name").toString().compareTo("stair")==0))
								{
									description = "Can't drive there";
									break;
								}
								else if((cell.getTile().getProperties().get("name").toString().compareTo("lampost")==0))
								{
									description = "Can't drive there";
									break;
								}
								else if((cell.getTile().getProperties().get("name").toString().compareTo("lampost top")==0))
								{
									description = "Can't drive there";
									break;
								}
							    mower.pos.set(point);
							    mower.moveRange.clear();
								mower.isFocused = false;
								Time++;
								stop=true;
								break;
							}
						}
						
						break;
				    }
				}
				
			}
		
			if((box.isFocused == true&&box.drive == null)||(box.drive!=null&&box.drive.isFocused))
			{
				//if(box.drive!=null)description = Boolean.toString(box.drive.isFocused);
				for(Vector2 point :box.moveRange)
				{
					if((clickPosx==point.x&&clickPosy==point.y)&&isClicked==false)
					{
						if(box.drive!=null)//&&box.drive.isFocused)
						{
						cell = tileLayer.getCell((int)point.x,(int)point.y);
						
						if((cell.getTile().getProperties().get("name").toString().compareTo("stair")==0))
						{
							description = "Can't drive there";
							break;
						}
						else if((cell.getTile().getProperties().get("name").toString().compareTo("lampost")==0))
						{
							description = "Can't drive there";
							break;
						}
						else if((cell.getTile().getProperties().get("name").toString().compareTo("lampost top")==0))
						{
							description = "Can't drive there";
							break;
						}
						}
						box.pos.set(point);
						box.damageSum +=box.damage;
						if(box.drive!=null)
							{box.drive.pos.set(point);
							description = "LCTRL to leave";
						}
						box.moveRange.clear();
						box.isFocused = false;
						if(box.drive!=null)box.drive.isFocused = false;
						//deliveryBox.moves--;
						
						Time++;
						stop=true;
						break;
					}
				}
				tileLayer = (TiledMapTileLayer)map.getLayers().get(box.floor);
				cell = tileLayer.getCell((int)box.pos.x,(int)box.pos.y);
				
				
				if(box.drive!=null&&(Gdx.input.isKeyPressed(Keys.CONTROL_LEFT)&&!stop))
				{
					box.drive.carrier = null;
					box.drive = null;
				}
				
				for(Mower mower :allMowers)
				{
					if((box.pos.x == mower.pos.x&&box.pos.y == mower.pos.y)&&box.drive == null)
					{
						description = "SPACE to drive mower";
						if(Gdx.input.isKeyPressed(Keys.SPACE)&&!stop)
						{
							box.drive = mower;
							mower.carrier = box;
							//System.out.println(mower.isFocused);
							stop=true;box.isFocused = false;
						}
					}
				}
				
				if(cell.getTile().getProperties().get("name").toString().compareTo("rocket")==0)
				{
					description = "SPACE to take you to the top";
					if(Gdx.input.isKeyPressed(Keys.SPACE)&&!stop)
					{
						cell.setTile(tileSet.getTile(8));
						tileLayer = (TiledMapTileLayer)map.getLayers().get(box.floor);
						tileLayer.setCell((int)box.pos.x,(int)box.pos.y, cell);
						description = "Use side mouse button to switch floor";
						box.floor = map.getLayers().getCount()-1;
						stop=true;box.isFocused = false;Time++;
						box.damageSum +=box.damage;
					}
				}
				if(cell.getTile().getProperties().get("name").toString().compareTo("air")==0)
				{
					description = "You FELL!";
					for(int i =box.floor;i>-1;i--)
					{
						tileLayer = (TiledMapTileLayer)map.getLayers().get(i);
						cell = tileLayer.getCell((int)box.pos.x,(int)box.pos.y);
						box.floor = i;
						if(cell.getTile().getProperties().get("name").toString().compareTo("air")!=0)
						{
							box.damageSum +=box.damage;
							Time++;
							break;
						}
					}
					stop=true;box.isFocused = false;
				}
				
				if(cell.getTile().getProperties().get("name").toString().compareTo("stair")==0)
				{
					description = "LCTRL to descend,SPACE to ascend";
					if(Gdx.input.isKeyPressed(Keys.CONTROL_LEFT)&&!stop)
					{
						if(box.floor>0)box.floor--;description = "Use side mouse button to switch floor";stop=true;box.isFocused = false;Time++;
					}
					else if(Gdx.input.isKeyPressed(Keys.SPACE)&&!stop)
					{
						if(box.floor<map.getLayers().getCount()-1)box.floor++;description = "Use side mouse button to switch floor";stop=true;box.isFocused = false;Time++;
					}
				
				}
                
				if(cell.getTile().getProperties().get("name").toString().compareTo("green door")==0)
				{
					description = "SPACE to deliver and take your prize!";
					if(Gdx.input.isKeyPressed(Keys.SPACE)&&!stop)
					{
						Money += box.reward; activePackages.removeValue(box, true);packages.free(box);maxDelivered++;stop=true;
						
					}
				}
				else if(cell.getTile().getProperties().get("name").toString().compareTo("blue door")==0)
				{
					description = "SPACE to deliver and take MORE prize!";
					if(Gdx.input.isKeyPressed(Keys.SPACE)&&!stop)
					{
						Money += (int)1.3*box.reward; activePackages.removeValue(box, true);packages.free(box);maxDelivered++;activePackages.removeValue(box, true); stop=true;
					}
				}
				else if(cell.getTile().getProperties().get("name").toString().compareTo("yellow door")==0)
				{
					description = "SPACE to deliver and take MORE MORE prize!";
					if(Gdx.input.isKeyPressed(Keys.SPACE)&&!stop)
					{
						Money += (int)1.5*box.reward; activePackages.removeValue(box, true);packages.free(box);maxDelivered++;activePackages.removeValue(box, true); stop=true;}
					}
				}
			    else if(cell.getTile().getProperties().get("name").toString().compareTo("red door")==0)
			    {
				    description = "SPACE to deliver and take GREAT prize!";
				    if(Gdx.input.isKeyPressed(Keys.SPACE)&&!stop)
				    {
					    Money += 2*box.reward; activePackages.removeValue(box, true);packages.free(box);maxDelivered++;activePackages.removeValue(box, true); stop=true;
				    }
			    }
			
				
				if(cell.getTile().getProperties().get("name").toString().compareTo("lampost")==0)
				{
					description = "SPACE to ascend,can be climbed UP only";

					if(Gdx.input.isKeyPressed(Keys.SPACE)&&!stop)
					{
						if(box.floor<map.getLayers().getCount()-1)box.floor++;description = "Use side mouse button to switch floor";stop=true;box.isFocused = false;Time++;
					}
					
				}
				if(cell.getTile().getProperties().get("name").toString().compareTo("lampost top")==0)
				{
					description = "LCTRL to descend,can be climbed DOWN only";

					if(Gdx.input.isKeyPressed(Keys.CONTROL_LEFT)&&!stop)
					{
						if(box.floor>0)box.floor--;stop=true;description = "Use side mouse button to switch floor";box.isFocused = false;Time++;
					}
					
				}
			
			box.setPos((SpriteBatch) renderer.getBatch(), (int)box.pos.x, (int)box.pos.y);
			font.draw((SpriteBatch) renderer.getBatch(), Integer.toString(box.reward),32*(box.pos.x+1),32*(box.pos.y+1));
			font.draw((SpriteBatch) renderer.getBatch(), Integer.toString(box.penalty),32*(box.pos.x+1),32*(box.pos.y+1)-16);
		    }
		
		    if(box.reward<0)
            {
            	description = "OVERTIME!";
            	Money -= 50; activePackages.removeValue(box, true);packages.free(box);
            }
			tileLayer = (TiledMapTileLayer)map.getLayers().get(box.floor);
			box.reward = box.rewardBase-box.penalty*(Time-box.spawnTime)-box.damageSum;
			cell = tileLayer.getCell(gridX, gridY);
			
	}
		for(Mower mower :allMowers)
		{
			if(mower.floor == cameraFloor)
			{
				mower.setPos((SpriteBatch) renderer.getBatch(), (int)mower.pos.x,(int)mower.pos.y);
			}
		}
		
		
		
			font.draw((SpriteBatch) renderer.getBatch(), Integer.toString(gridY),cursorPosx+40,cursorPosy+10);
			font.draw((SpriteBatch) renderer.getBatch(), Integer.toString(gridX),cursorPosx+10,cursorPosy+10);
			if(this.cell!=null)font.draw((SpriteBatch) renderer.getBatch(), cell.getTile().getProperties().get("name").toString(),cursorPosx+70,cursorPosy+10);
			font.draw((SpriteBatch) renderer.getBatch(), description,100,100);
			font.draw((SpriteBatch) renderer.getBatch(), Integer.toString(Time)+timePassed,100,500);
			font.draw((SpriteBatch) renderer.getBatch(), Integer.toString(Money)+moneyLeft,600,500);
			font.draw((SpriteBatch) renderer.getBatch(), Selected,cursorPosx+10,cursorPosy);
			maxMoney = Math.max(maxMoney, Money);
			if(Money <= 0)
	        {
	        	this.dispose();
	        	Game.setScreen(new GameOverScreen(Game,maxMoney,maxDelivered));
	        }
		renderer.getBatch().end();
		//batch.end();
		rectRenderer.setProjectionMatrix(camera.combined);
		rectRenderer.begin(ShapeType.Line);
		rectRenderer.setColor(Color.WHITE);
		rectRenderer.rect(gridX*32, gridY*32, 32f,32f);
		rectRenderer.end();
	}

	private void gridUpdate()
	{
		for(int x = 0;x<30;x++)
		{
			if(x*32<= cursorPosx&& cursorPosx <(x+1)*32)
			{
				gridX = x;
				for(int y = 0;y<20;y++)
				{
					if(y*32<= cursorPosy&&cursorPosy <(y+1)*32)
					{
						gridY = y;
					}
				}
			}	
		}
	}
	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean keyDown(int keycode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean keyTyped(char character) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		cursorPosx = screenX;
		cursorPosy = Gdx.graphics.getHeight() - screenY;
		if(button == Buttons.LEFT)
			{
			isClicked = true;	
			clickPosx = gridX;
			clickPosy = gridY;
			}
		else if(button == Buttons.FORWARD&&cameraFloor<map.getLayers().getCount()-1)
		{
			cameraFloor++;
			
		}
		else if(button == Buttons.BACK&&cameraFloor>0)
		{
			cameraFloor--;
		}
		return true;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		if(stop)stop = false;
		isClicked = false;
		return true;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		// TODO Auto-generated method stub
		cursorPosx = screenX;
		cursorPosy = Gdx.graphics.getHeight() - screenY;
		return true;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		// TODO Auto-generated method stub
		cursorPosx = screenX;
		cursorPosy = Gdx.graphics.getHeight() - screenY;
		return false;
	}

	@Override
	public boolean scrolled(float amountX, float amountY) {
		// TODO Auto-generated method stub
		return false;
	}

	private void spawnPackage()
	{
		int initPosX = 0,initPosY = 0;
        if(activePackages.size<3)
        {
        	Package pkg = packages.obtain();
        	switch((int)(Math.ceil(Math.random()*5))) 
        	{
        	
        	case 1 :
        		initPosX = (int)(Math.floor(Math.random()*30));
        		initPosY = (int)(Math.floor(Math.random()*2));
        	    for(Package pak:activePackages)
        	    {
        	    	if(pak.pos.x == initPosX&&pak.pos.y == initPosY)
        	    	{
        	    		initPosX = (int)(Math.floor(Math.random()*30));
                		initPosY = (int)(Math.floor(Math.random()*2));
        	    	}
        	    }
        	    pkg = new Package(initPosX,initPosY,map,Time);
        	    activePackages.add(pkg);
        	    break;
        	case 2 :
        		initPosX = (int)(Math.floor(Math.random()*30));
        		initPosY = (int)(Math.floor(Math.random()*2));
        	    for(Package pak:activePackages)
        	    {
        	    	if(pak.pos.x == initPosX&&pak.pos.y == initPosY)
        	    	{
        	    		initPosX = (int)(Math.floor(Math.random()*30));
                		initPosY = (int)(Math.floor(Math.random()*2));
        	    	}
        	    }
        	    pkg = new SkateBoard(initPosX,initPosY,map,Time);
        	    activePackages.add(pkg);
        	    break;
        	case 3 :
        		initPosX = (int)(Math.floor(Math.random()*30));
        		initPosY = (int)(Math.floor(Math.random()*2));
        	    for(Package pak:activePackages)
        	    {
        	    	if(pak.pos.x == initPosX&&pak.pos.y == initPosY)
        	    	{
        	    		initPosX = (int)(Math.floor(Math.random()*30));
                		initPosY = (int)(Math.floor(Math.random()*2));
        	    	}
        	    }
        	    pkg = new Laptop(initPosX,initPosY,map,Time);
        	    activePackages.add(pkg);
        	    break;
        	case 4 :
        		initPosX = (int)(Math.floor(Math.random()*30));
        		initPosY = (int)(Math.floor(Math.random()*2));
        	    for(Package pak:activePackages)
        	    {
        	    	if(pak.pos.x == initPosX&&pak.pos.y == initPosY)
        	    	{
        	    		initPosX = (int)(Math.floor(Math.random()*30));
                		initPosY = (int)(Math.floor(Math.random()*2));
        	    	}
        	    }
        	    pkg = new VideoGame1(initPosX,initPosY,map,Time);
        	    activePackages.add(pkg);
        	    break;
        	case 5 :
        		initPosX = (int)(Math.floor(Math.random()*30));
        		initPosY = (int)(Math.floor(Math.random()*2));
        	    for(Package pak:activePackages)
        	    {
        	    	if(pak.pos.x == initPosX&&pak.pos.y == initPosY)
        	    	{
        	    		initPosX = (int)(Math.floor(Math.random()*30));
                		initPosY = (int)(Math.floor(Math.random()*2));
        	    	}
        	    }
        	    pkg = new VideoGame2(initPosX,initPosY,map,Time);
        	    activePackages.add(pkg);
        	    break;
        	default :
        		break;
        	}
        }
	}
}
