package com.badb4dguy.deliverysim;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.utils.ScreenUtils;

public class GameOverScreen implements Screen{
    final MyGdxGame Game;
    OrthographicCamera camera;
    int money;
    int delivered;
	public GameOverScreen(final MyGdxGame game,int money,int delivered) {
 		this.Game = game;
        this.money = money;
        this.delivered = delivered;
 		camera = new OrthographicCamera();
 		camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
}
	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		if(delivered>10)
		{
		ScreenUtils.clear(1, 0.97f, 0.19f, 1);
		}
		else if(delivered>=5)
		{
			ScreenUtils.clear(0.3f, 0.65f, 1, 1);
		}
		else if(delivered>=0)
		{
			ScreenUtils.clear(0.56f, 0.87f, 0.36f, 1);
		}
		camera.update();
		Game.batch.setProjectionMatrix(camera.combined);
		Game.batch.begin();
		Game.font.draw(Game.batch, "You made it with"+Integer.toString(delivered)+"packages delivered",200,130);
		Game.font.draw(Game.batch, "Tap Anywhere 2 Restart",200,100);
		Game.batch.end();
		if (Gdx.input.isTouched()) {
			Game.setScreen(new GameScreen(Game));
			dispose();
		}
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
