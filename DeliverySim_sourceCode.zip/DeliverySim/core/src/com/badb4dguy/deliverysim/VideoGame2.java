package com.badb4dguy.deliverysim;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.math.Vector2;

public class VideoGame2 extends Package{
    
	public VideoGame2(int initX, int initY, TiledMap map,int spawnTime) {
		super(initX, initY, map,spawnTime);
		boxTexture = new Texture("Videogame2.png");
		this.penalty = 0;
		this.rewardBase = 120;
		this.damage = 5;
		// TODO Auto-generated constructor stub
	}
	@Override
	void onSelected(SpriteBatch batch,TiledMapTileLayer Layer)
	{
		if (isFocused&&drive!=null)
		{
			isFocused = false;
			drive.isFocused = true;
			drive.onSelected(batch, Layer);
			moveRange = this.drive.moveRange;
		}
		if(isFocused)
		{
		for(int x = -1;x<2;x+=1)
		{
			//probe = layer.getCell((int)pos.x+x, (int)pos.y);
			
			for(int y = -1;y<2;y+=1)
			{
				layer = Layer;
				probe = layer.getCell((int)pos.x+x, (int)pos.y+y);
				
				if(probe!=null&&!(boolean)probe.getTile().getProperties().get("canBlockMovement")&&(x!=0||y!=0))
				{
					batch.draw(moveGrid,32*((int)pos.x+x), 32*((int)pos.y+y));	
                    destination.set((int)pos.x+x, (int)pos.y+y);
                    moveRange.add(new Vector2(destination));
                    //moveRange.insert((x+1)*3+y+1, destination);
				}
				
			}
		}
		}
		else if(!isFocused)
		{
			return;
		}
	}
	@Override
	void setPos(SpriteBatch batch,int x,int y)
	{
		batch.draw(boxTexture,x*32, y*32);	
	}
}
