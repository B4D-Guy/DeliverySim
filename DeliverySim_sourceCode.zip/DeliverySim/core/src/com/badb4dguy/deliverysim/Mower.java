package com.badb4dguy.deliverysim;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;

public class Mower extends Package{
	public Package carrier;
	
	public Mower(int initX, int initY, TiledMap map,int spawnTime) {
		// TODO Auto-generated constructor stub
		super(initX, initY, map,spawnTime);
		
		carrier = null;
		boxTexture = new Texture("Mower.png");
		moveGrid = new Texture("Mower_move.png");
	}

	
	
	
		
		@Override
		void onSelected(SpriteBatch batch,TiledMapTileLayer Layer)
		{

			if(isFocused)
			{
			   for(int x = -3;x<4;x+=1)
			   {
				for(int y = -3;y<4;y+=1)
				{
					layer = Layer;
					probe = layer.getCell((int)pos.x+x, (int)pos.y+y);
					
					if(probe!=null&&!(boolean)probe.getTile().getProperties().get("canBlockMovement")&&((x!=0&&y==0)||(x==0&&y!=0)))
					{
						probe = layer.getCell((int)pos.x+zero(x/3), (int)pos.y+zero(y/3));
						if(!(boolean)probe.getTile().getProperties().get("canBlockMovement"))
						{
						batch.draw(moveGrid,32*((int)pos.x+x), 32*((int)pos.y+y));	
	                    destination.set((int)pos.x+x, (int)pos.y+y);
	                    moveRange.add(new Vector2(destination));
	                    //carrier.moveRange.add(new Vector2(destination));
	                    
						} 
					}
				}
			}
			}
			else if(!isFocused)
			{
				return;
			}
			
}
		void setPos(SpriteBatch batch,int x,int y)
		{
			batch.draw(boxTexture,x*32, y*32);	
		}
		private int zero(int a)
		{
			if(a>0&&a<1) a =1;
			else if(a<0&&a>-1) a =-1;
			else if (a>=1||a<=-1) return a;
			return a;
		}}
