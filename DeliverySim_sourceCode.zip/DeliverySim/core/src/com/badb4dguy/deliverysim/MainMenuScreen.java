package com.badb4dguy.deliverysim;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.utils.ScreenUtils;

public class MainMenuScreen implements Screen{
	     final MyGdxGame Game;
	     OrthographicCamera camera;
	     //BitmapFont titleFont;
	     Texture cover;
	     public MainMenuScreen(final MyGdxGame game) {
	 		this.Game = game;
            cover = new Texture("Untitled.png");
	 		camera = new OrthographicCamera();
	 		camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
}
		@Override
		public void show() {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void render(float delta) {
			// TODO Auto-generated method stub
			ScreenUtils.clear(1, 0.59f, 0.44f, 1);
			camera.update();
			Game.batch.setProjectionMatrix(camera.combined);
			Game.batch.begin();
			Game.batch.draw(cover,0,0);
			Game.font.setColor(Color.BLACK);
			Game.font.draw(Game.batch, "Made for Ludum Dare 53",330,150);
			
			Game.font.draw(Game.batch, "Tap Anywhere 2 Begin",200,100);
			
			Game.batch.end();
			if (Gdx.input.isTouched()) {
				Game.setScreen(new GameScreen(Game));
				dispose();
			}
		}
		@Override
		public void resize(int width, int height) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void pause() {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void resume() {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void hide() {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void dispose() {
			// TODO Auto-generated method stub
			
		}
}

